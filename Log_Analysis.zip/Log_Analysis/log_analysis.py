import re
from collections import defaultdict
import csv

# Path to the log file
log_file = "server_log.log"

def extract_ip_from_log(log_line):
    """Extract the IP address from a log line."""
    ip_match = re.match(r'^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', log_line)
    return ip_match.group(1) if ip_match else None

def extract_endpoint_from_log(log_line):
    """Extract the endpoint from a log line."""
    endpoint_match = re.search(r'\"[A-Z]+\s(\/\S*)\s', log_line)
    return endpoint_match.group(1) if endpoint_match else None

def process_log_file(log_file):
    """Process the log file and extract request counts, endpoint access, and failed logins."""
    ip_requests = defaultdict(int)
    endpoint_access = defaultdict(int)
    failed_logins = defaultdict(int)

    with open(log_file, "r") as file:
        for line in file:
            ip = extract_ip_from_log(line)
            endpoint = extract_endpoint_from_log(line)
            
            if ip:
                ip_requests[ip] += 1

            if endpoint:
                endpoint_access[endpoint] += 1

            if "POST /login" in line and "401" in line:
                failed_logins[ip] += 1

    return ip_requests, endpoint_access, failed_logins

def detect_suspicious_activity(failed_logins):
    """Detect suspicious IPs with multiple failed login attempts."""
    # Set threshold for suspicious activity
    threshold = 2
    suspicious_ips = {ip: count for ip, count in failed_logins.items() if count >= threshold}
    return suspicious_ips

def save_to_csv(data, file_name, header):
    """Save data to a CSV file."""
    with open(file_name, mode="w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(header)
        writer.writerows(data)

def main():
    # Process the log file
    ip_requests, endpoint_access, failed_logins = process_log_file(log_file)

    # Prepare data for Requests Per IP Address
    ip_data = sorted(ip_requests.items(), key=lambda x: x[1], reverse=True)
    print("Requests Per IP Address:")
    for ip, count in ip_data:
        print(f"{ip}: {count}")
    save_to_csv(ip_data, "ip_requests.csv", ["IP Address", "Request Count"])

    # Prepare data for Most Frequently Accessed Endpoint
    most_accessed_endpoint = sorted(endpoint_access.items(), key=lambda x: x[1], reverse=True)
    print("\nMost Frequently Accessed Endpoint:")
    if most_accessed_endpoint:
        print(f"{most_accessed_endpoint[0][0]}: {most_accessed_endpoint[0][1]} accesses")
    save_to_csv(most_accessed_endpoint, "endpoint_access.csv", ["Endpoint", "Access Count"])

    # Prepare data for Suspicious Activity
    suspicious_ips = detect_suspicious_activity(failed_logins)
    print("\nSuspicious Activity Detected:")
    if suspicious_ips:
        for ip, count in suspicious_ips.items():
            print(f"{ip}: {count} failed login attempts")
    else:
        print("No suspicious activity detected.")
    save_to_csv(suspicious_ips.items(), "suspicious_activity.csv", ["IP Address", "Failed Login Count"])

if __name__ == "__main__":
    main()
